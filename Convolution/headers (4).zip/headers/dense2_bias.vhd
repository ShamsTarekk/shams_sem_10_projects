dense2_b := (
to_signed(int32_t dense2_b[] = 
-1780,32), to_signed(666,32), to_signed(-298,32), to_signed(554,32), to_signed(80,32), to_signed(430,32), to_signed(211,32), to_signed(-339,32), to_signed(-766,32), to_signed(290,32), to_signed(-128,32), to_signed(380,32), to_signed(;,32), 
);
