dense1_b := (
to_signed(int32_t dense1_b[] = 
1,32), to_signed(-22,32), to_signed(10,32), to_signed(-4,32), to_signed(-7,32), to_signed(1,32), to_signed(26,32), to_signed(3,32), to_signed(-9,32), to_signed(4,32), to_signed(-35,32), to_signed(-19,32), to_signed(12,32), to_signed(26,32), to_signed(3,32), to_signed(-30,32), 
to_signed(;,32), 
);
