conv2_b := (
to_signed(int32_t conv2_b[] = 
-770,32), to_signed(-378,32), to_signed(135,32), to_signed(-27,32), to_signed(-499,32), to_signed(491,32), to_signed(928,32), to_signed(274,32), to_signed(1454,32), to_signed(394,32), to_signed(-285,32), to_signed(-410,32), to_signed(71,32), to_signed(-39,32), to_signed(-262,32), to_signed(-43,32), 
to_signed(-195,32), to_signed(-499,32), to_signed(179,32), to_signed(-326,32), to_signed(177,32), to_signed(-543,32), to_signed(2572,32), to_signed(-53,32), to_signed(-78,32), to_signed(2731,32), to_signed(-23,32), to_signed(-100,32), to_signed(206,32), to_signed(122,32), to_signed(;,32), 
);
