conv1_b := (
to_signed(int32_t conv1_b[] = 
-164,32), to_signed(-291,32), to_signed(-115,32), to_signed(97,32), to_signed(308,32), to_signed(-38,32), to_signed(-79,32), to_signed(-81,32), to_signed(-143,32), to_signed(-231,32), to_signed(-163,32), to_signed(-102,32), to_signed(-46,32), to_signed(-54,32), to_signed(-80,32), to_signed(-159,32), 
to_signed(-89,32), to_signed(217,32), to_signed(-203,32), to_signed(-169,32), to_signed(192,32), to_signed(-108,32), to_signed(-207,32), to_signed(-7,32), to_signed(-51,32), to_signed(-17,32), to_signed(106,32), to_signed(-196,32), to_signed(;,32), 
);
